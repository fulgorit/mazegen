/****************************************************************************
**
** Copyright (C) 2011 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
** Contact: Nokia Corporation (qt-info@nokia.com)
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Nokia Corporation and its Subsidiary(-ies) nor
**     the names of its contributors may be used to endorse or promote
**     products derived from this software without specific prior written
**     permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
** $QT_END_LICENSE$
**
****************************************************************************/

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "mazebacktracking.h"
#include "maze.h"
#include <stdlib.h>
#include <time.h>
#include <QGraphicsItem>
#include <QPicture>
#include <QPainter>
#include <QDebug>
#include <QDir>
#include <QString>
#include <QFileDialog>
#include <QMessageBox>

#define MAX 61  // 30 * 2 + 1
#define CELL 900  // 30 * 30
#define WALL 1
#define PATH 0
#define RED  2
#define START 3
#define GOAL 4

#include <QtGui>

#include <math.h>

#include "renderthread.h"


RenderThread::RenderThread(QObject *parent)
    : QThread(parent)
{

   running=0;

}

RenderThread::~RenderThread()
{


}

void RenderThread::render(int size,int n)
{

    m_size=size;

    QMutexLocker locker(&mutex);

    // qDebug() << "render";

    mmaze=new mazeBacktracking(m_size,false,1);

    if(n==0) mmaze->maze_generator_1();
    if(n==1) mmaze->maze_generator_2();
    if(n==2) mmaze->maze_generator_3();
    running=1;

    //qDebug() << running;
    emit renderedImage();

}

void RenderThread::solve()
{


    toSolve1=new mazeData(mmaze->maze);

    toSolve1->setStart(1,0);

    toSolve1->setEnd(toSolve1->m_size-2,toSolve1->m_size-1);

//  qDebug() << "NOMBRE DE PATHS:" << countPaths();

    if(find_path(1,1)) emit mazeSolved();



}

void RenderThread::run()
{


    //emit renderedImage();


}

int RenderThread::countPaths()
{

  int TAB[27][27];

  for(int i=0;i<mmaze->size;i++)
  {

    for(int j=0;j<mmaze->size;j++)
    {

        TAB[i][j]=0;

    }

  }

  // If the initial cell is blocked, there is no
  // way of moving anywhere
  if (toSolve1->maze_data[0][0]==-1)
      return 0;

  // Initializing the leftmost column
  for (int i=0; i<mmaze->size; i++)
  {
      if (toSolve1->maze_data[i][0] == 0)
          TAB[i][0] = 1;

      // If we encounter a blocked cell in leftmost
      // row, there is no way of visiting any cell
      // directly below it.
      else
          break;
  }

  // Similarly initialize the topmost row
  for (int i=1; i<mmaze->size; i++)
  {
      if (toSolve1->maze_data[0][i] == 0)
          TAB[0][i] = 1;

      // If we encounter a blocked cell in bottommost
      // row, there is no way of visiting any cell
      // directly below it.
      else
          break;
  }

  // The only difference is that if a cell is -1,
  // simply ignore it else recursively compute
  // count value maze[i][j]
  for (int i=1; i< mmaze->size; i++)
  {
      for (int j=1; j< mmaze->size; j++)
      {
          // If blockage is found, ignore this cell
          if (toSolve1->maze_data[i][j] == -1)
              continue;

          // If we can reach maze[i][j] from maze[i-1][j]
          // then increment count.
          if (toSolve1->maze_data[i-1][j] > 0)
              TAB[i][j] = (toSolve1->maze_data[i][j] + toSolve1->maze_data[i-1][j]);

          // If we can reach maze[i][j] from maze[i][j-1]
          // then increment count.
          if (toSolve1->maze_data[i][j-1] > 0)
              TAB[i][j] = (toSolve1->maze_data[i][j] + toSolve1->maze_data[i][j-1]);
      }
  }

  for(int i=0;i<mmaze->size;i++)
  {

    for(int j=0;j<mmaze->size;j++)
    {

//        qDebug() << TAB[i][j];

    }

  }

  // If the final cell is blocked, output 0, otherwise
  // the answer
  return (TAB[mmaze->size-1][mmaze->size-1] > 0)? TAB[mmaze->size-1][mmaze->size-1] : 0;

}

bool RenderThread::find_path(int x, int y)
{
//not the shortest path

        int maze_size=mmaze->size*2;

        if ( x < 0 || x > maze_size  || y < 0 || y > maze_size  ) return FALSE;

        if ( toSolve1->maze_data[y][x] == GOAL ) return TRUE;

        if ( toSolve1->maze_data[y][x] != PATH && toSolve1->maze_data[y][x] != START ) return FALSE;

        toSolve1->setRed(y,x);



        if ( find_path(x, y - 1) == TRUE ) return TRUE;

        if ( find_path(x + 1, y) == TRUE ) return TRUE;

        if ( find_path(x, y + 1) == TRUE ) return TRUE;

        if ( find_path(x - 1, y) == TRUE ) return TRUE;

        toSolve1->setPath(y,x);

        return FALSE;


}
